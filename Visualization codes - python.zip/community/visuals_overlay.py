
import pandas as pd
import networkx as nx
import plotly.graph_objects as go

# Load COMM_OVERLAP_OUT
overlap_df = pd.read_csv("/Users/oeze/Downloads/network_project/community/COMM_OVERLAP_OUT.csv")

# Clean column names
overlap_df.columns = overlap_df.columns.str.strip().str.lower()

# Expected fields: node, community, intensity
if not {'node', 'community', 'intensity'}.issubset(overlap_df.columns):
    raise ValueError("COMM_OVERLAP_OUT must contain 'node', 'community', and 'intensity' columns.")

# Create bipartite graph
G = nx.Graph()

# Add species and community nodes
species_nodes = overlap_df['node'].unique()
community_nodes = overlap_df['community'].unique()

G.add_nodes_from(species_nodes, bipartite=0, type='species')
G.add_nodes_from(community_nodes, bipartite=1, type='community')

# Add edges with intensity as weight and label
for _, row in overlap_df.iterrows():
    G.add_edge(row['node'], row['community'], weight=row['intensity'])

# Layout
pos = nx.spring_layout(G, seed=42)

# Build edge trace
edge_x, edge_y, edge_text = [], [], []
for u, v, d in G.edges(data=True):
    x0, y0 = pos[u]
    x1, y1 = pos[v]
    edge_x += [x0, x1, None]
    edge_y += [y0, y1, None]
    edge_text.append(f"{u} ↔ {v}<br>Intensity: {d['weight']}")

# Plot edge lines
edge_trace = go.Scatter(
    x=edge_x, y=edge_y, mode='lines',
    line=dict(color='gray', width=1),
    hoverinfo='text',
    text=edge_text
)

# Node visuals
node_x, node_y, node_text, node_color, node_size = [], [], [], [], []
for node in G.nodes():
    x, y = pos[node]
    node_x.append(x)
    node_y.append(y)
    node_type = G.nodes[node]['type']
    node_text.append(f"{node_type.title()}: {node}")
    node_color.append(0 if node_type == 'species' else 1)
    node_size.append(10 if node_type == 'species' else 20)

node_trace = go.Scatter(
    x=node_x, y=node_y, mode='markers+text',
    textposition='top center', hoverinfo='text',
    text=[str(n) for n in G.nodes()],
    marker=dict(
        size=node_size,
        color=node_color,
        colorscale='Viridis',
        showscale=True,
        colorbar=dict(title='Node Type (0=Species, 1=Community)')
    ),
    hovertext=node_text
)

# Final layout
fig = go.Figure(data=[edge_trace, node_trace],
    layout=go.Layout(
        title='Overlapping Communities with Intensity Labels',
        hovermode='closest',
        showlegend=False,
        margin=dict(b=20, l=5, r=5, t=40),
        xaxis=dict(showgrid=False, zeroline=False),
        yaxis=dict(showgrid=False, zeroline=False)
    )
)

fig.show()
