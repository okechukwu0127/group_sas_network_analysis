import pandas as pd
import networkx as nx
import plotly.graph_objects as go

# Load data
comm_out_df = pd.read_csv("/Users/oeze/Downloads/network_project/community/COMM_OUT.csv")
comm_links_df = pd.read_csv("/Users/oeze/Downloads/network_project/community/COMM_LINKS_OUT.csv")

# Clean and standardize column names
comm_out_df.columns = comm_out_df.columns.str.lower().str.strip()
comm_links_df.columns = comm_links_df.columns.str.lower().str.strip()

# Create the graph
G = nx.Graph()

# Add nodes with their community sizes and IDs
for _, row in comm_out_df.iterrows():
    community_id = str(row['community']).strip()
    G.add_node(community_id, size=row['nodes'], group=community_id)

# Add edges between communities with weights
for _, row in comm_links_df.iterrows():
    from_node = str(row['from_community']).strip()
    to_node = str(row['to_community']).strip()
    weight = float(row['link_weight'])
    G.add_edge(from_node, to_node, weight=weight)

# Create layout
pos = nx.spring_layout(G, seed=42)

# Extract edge coordinates and labels
edge_x, edge_y = [], []
edge_label_x, edge_label_y, edge_weights = [], [], []

for u, v, data in G.edges(data=True):
    x0, y0 = pos[u]
    x1, y1 = pos[v]
    edge_x += [x0, x1, None]
    edge_y += [y0, y1, None]
    edge_label_x.append((x0 + x1) / 2)
    edge_label_y.append((y0 + y1) / 2)
    edge_weights.append(f"{data['weight']:.2f}")

# Extract node coordinates and info
node_x, node_y, node_text, node_color = [], [], [], []
for node in G.nodes():
    x, y = pos[node]
    node_x.append(x)
    node_y.append(y)
    node_text.append(f"Community: {node}<br>Size: {G.nodes[node]['size']}")
    node_color.append(float(G.nodes[node]['group']))

# Create edge trace
edge_trace = go.Scatter(
    x=edge_x, y=edge_y,
    mode='lines', line=dict(color='gray', width=1),
    hoverinfo='none'
)

# Create edge label trace
edge_label_trace = go.Scatter(
    x=edge_label_x, y=edge_label_y,
    mode='text',
    text=edge_weights,
    textposition='middle center',
    hoverinfo='none',
    textfont=dict(color='black', size=10)
)

# Create node trace
node_trace = go.Scatter(
    x=node_x, y=node_y,
    mode='markers+text', textposition='top center',
    text=[str(n) for n in G.nodes()],
    hoverinfo='text',
    marker=dict(
        size=[G.nodes[n]['size'] * 2 for n in G.nodes()],
        color=node_color,
        colorscale='Viridis',
        showscale=True,
        colorbar=dict(title="Community ID")
    ),
    hovertext=node_text
)

# Combine and plot
fig = go.Figure(data=[edge_trace, edge_label_trace, node_trace],
    layout=go.Layout(
        title='Community Network Visualization',
        hovermode='closest',
        showlegend=False,
        margin=dict(b=20, l=5, r=5, t=40),
        xaxis=dict(showgrid=False, zeroline=False),
        yaxis=dict(showgrid=False, zeroline=False)
    )
)

fig.show()
