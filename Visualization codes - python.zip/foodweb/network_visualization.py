# Save this script as network_visualization.py

import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt

# Load the links data from the CSV
df = pd.read_csv('/Users/oeze/Downloads/network_project/foodweb/concompKC.csv')  # Update with your file path

# Create a graph from the edge list (pairs of nodes)
G = nx.Graph()
for _, row in df.iterrows():
    G.add_edge(row['from'], row['to'])

# Draw the network graph
nx.draw(G, with_labels=True, node_color='skyblue', node_size=2000, font_size=10)
plt.title("Network Diagram")
plt.show()
