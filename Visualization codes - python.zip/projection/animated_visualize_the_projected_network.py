

import pandas as pd
import networkx as nx
import plotly.graph_objects as go

# Load the projection data
links = pd.read_csv('/Users/oeze/Downloads/network_project/projection/PROJECTION_LINK.csv')
nodes = pd.read_csv('/Users/oeze/Downloads/network_project/projection/PROJECTION.csv')

# Create graph
G = nx.Graph()

# Add edges with weight = common neighbors
for _, row in links.iterrows():
    G.add_edge(str(row['from']), str(row['to']), weight=row['commonNeighbors'])

# Add node attributes (e.g., partition group for coloring)
partition_map = dict(zip(nodes['node'].astype(str), nodes['partitionFlag']))
nx.set_node_attributes(G, partition_map, 'partition')

# Layout
pos = nx.spring_layout(G, seed=42)

# Build traces
edge_x, edge_y = [], []
for u, v in G.edges():
    x0, y0 = pos[u]
    x1, y1 = pos[v]
    edge_x += [x0, x1, None]
    edge_y += [y0, y1, None]

node_x, node_y, node_text, node_color = [], [], [], []
for node in G.nodes():
    x, y = pos[node]
    node_x.append(x)
    node_y.append(y)
    node_text.append(f"Node: {node}<br>Group: {G.nodes[node]['partition']}")
    node_color.append(G.nodes[node]['partition'])

# Plot
edge_trace = go.Scatter(x=edge_x, y=edge_y, mode='lines', line=dict(color='gray', width=1), hoverinfo='none')
node_trace = go.Scatter(
    x=node_x, y=node_y, mode='markers+text', textposition='top center',
    hoverinfo='text', text=[str(n) for n in G.nodes()],
    marker=dict(size=10, color=node_color, colorscale='Viridis', showscale=True, colorbar=dict(title="Group")),
    hovertext=node_text
)

fig = go.Figure(data=[edge_trace, node_trace],
    layout=go.Layout(
        title='Projected Network Visualization',
        showlegend=False,
        hovermode='closest',
        margin=dict(b=20, l=5, r=5, t=40),
        xaxis=dict(showgrid=False, zeroline=False),
        yaxis=dict(showgrid=False, zeroline=False)
    )
)

fig.show()
